import { DataTypes } from 'sequelize';
import sequelize from '../../common/dbConfig';

const givenStuffEntity = sequelize.define('givenStuffs', {

});

export default givenStuffEntity;
