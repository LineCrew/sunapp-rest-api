import { DataTypes } from 'sequelize';
import sequelize from '../../common/dbConfig';

/**
 * 광고 기록 엔티티
 */

const AdvertiseHistoryEntity = sequelize.define('advertiseHistory', {
  //
});

export default AdvertiseHistoryEntity;
