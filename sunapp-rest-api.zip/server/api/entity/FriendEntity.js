import sequelize from '../../common/dbConfig';

/**
 * Friend Entity
 */
const gameEntity = sequelize.define('friends', {
});

export default gameEntity;
