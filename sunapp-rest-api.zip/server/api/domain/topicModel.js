export default class TopicModel {
  constructor(data = {}) {
    this.topicName = data.topicName;
    this.gameId = data.gameId;
  }
}
