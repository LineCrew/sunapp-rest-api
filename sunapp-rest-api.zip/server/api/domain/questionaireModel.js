export default class QuestionaireModel {
  constructor(data = {}) {
    this.topicId = data.topicId;
    this.questionaireName = data.questionaireName;
  }
}

