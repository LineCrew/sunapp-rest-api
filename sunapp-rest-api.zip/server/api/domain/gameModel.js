/**
 * GameModel.js
 * Author: Jude Park
 */
export default class GameModel {
  constructor(data = {}) {
    this.gameName = data.gameName;
  }
}

